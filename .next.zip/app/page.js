import { redirect } from 'next/navigation';

export default function Home() {
	return (
		<main>
			<h1>Quiz App</h1>
		</main>
	);
}
