export default function Dashboard() {
	return (
		<main>
			<h1>Quiz App</h1>
		</main>
	);
}
